/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "TraitementdeSignal.h"

uint32_t blockSize=BLOCK_SIZE;
uint32_t numBlocks=TEST_LENGTH_SAMPLES/BLOCK_SIZE;
// Low pass pour avoir le DC
void FiltreLowPass(float* buffer ,float* filteredSignal) {
    
    //uint32_t compteur;
    arm_fir_instance_f32 S;
    arm_fir_init_f32(&S,NUM_TAPS,(float32_t *) &firCoeffs32_LowPass[0],&firStateF32[0],blockSize);
    arm_fir_f32(&S,buffer,filteredSignal,blockSize);
    
    //CECI EST UTILISE POUR FILTRER L'ENSEMBLE DES ENCHANTILLONS
   /* for (uint32_t compteur=0; compteur< numBlocks; compteur++){
        arm_fir_f32(&S,buffer + (compteur*blockSize),filteredSignal+ (compteur*blockSize),blockSize);
       
        
    }*/
}
    
// high pass pour avoir le AC
void FiltreHighPass(float* buffer ,float* filteredSignal) {
    
    //uint32_t compteur;
    arm_fir_instance_f32 S;
    arm_fir_init_f32(&S,NUM_TAPS,(float32_t *) & firCoeffs32_HighPass[0],&firStateF32[0],blockSize);
    arm_fir_f32(&S,buffer,filteredSignal,blockSize);
    
    //CECI EST UTILISE POUR FILTRER L'ENSEMBLE DES ENCHANTILLONS
    /*for (uint32_t compteur=0; compteur< numBlocks; compteur++){
        arm_fir_f32(&S,buffer + (compteur*blockSize),filteredSignal+ (compteur*blockSize),blockSize);
    }*/
    
}

/*void FiltreMoyenne(float* signal, uint16_t index){

    float moyenne = 0.0;
    bool noZero = true;
    
    for(int j=0; j<11;j++){
        if(signal[j-5]<3000){
            noZero = false;
        }
    }
    if(noZero){
        for(int i=0; i<11;i++){
            moyenne+=signal[i-5];
        }
        signal[index] = moyenne/11.0;
    }
    
}*/

float calculerMoyenne(uint16_t index){
    float moyenne = 0.0;
    
    for(int i = index - (BLOCK_SIZE-1); i<=index ;i++){
        moyenne += dataSpo2[RED][AC][i];
    }
    
    return (float) moyenne/BLOCK_SIZE;

}

uint8_t calculBPM(uint16_t index){
    
        uint8_t nb_battements = 0;
        uint16_t position[2] = {0,0}; // position des pics des 2 pulses pour calculer BPM
        float treshold = 0.0; // treshold utilise pour determiner le debut et la fin d'un pulse
        float facteur = 1.75; //facteur multiplicatif du treshold par rapport a la moyenne d'une intervalle
        BPM = 0;
        uint16_t pulse[2] = {0,0}; // pour garder le debut et la fin d'un pulse en tete
        uint16_t curseur = 0;
        
        //0) METTRE UN TRESHOLD
                    // 0.1) Calculer moyenne sur un intervalle    
                    // 0.2) Calculer le treshold
                        treshold = facteur * calculerMoyenne(index); //0.1 et 0.2 fait en un
                        
                        
        for(curseur = index - (BLOCK_SIZE-1); (curseur<=index) && nb_battements<2; curseur++){ // on s'assure qu'on ne prend que deux battements pour notre BPM avec nb_battements <2
        // 1) CHERCHER UN PULSE LOCAL
            
                //1.1 est devenu le point 0 (avant cette boucle for)  
            
        		//1.2) SE DEPLACER A PARTIR DU DEBUT DU SIGNAL
                //on s'assure qu'on s'arrete des qu'on descend en bas du treshold avec le pulse[1]==0
        		    //1.3) COMPARER AVEC TRESHOLD     
        		    //1.4) SI SUPERIEUR OU EGAL AU TRESHOLD
                    if(dataSpo2[RED][AC][curseur]>=treshold && pulse[0] == 0){
        			    //1.4.1) ENREGISTRER LA POSITION DU DEBUT
                            pulse[0] = curseur;
                        }
        		//1.5) CONTINUER A SE DEPLACER
                    
                    
        		//1.6) SI INFERIEUR OU EGAL AU TRESHOLD
                    if(dataSpo2[RED][AC][curseur]<=treshold && pulse[1] ==0 && pulse[0] !=0){ //vertifie que je suis encore au milieu d'un pulse
        			    //1.6.1) SAUVEGARDER LA POSITION DE FIN
                        pulse[1] = curseur;
                    }
                    
                    
                    
		    //UNE FOIS QUE NOUS AVONS LA PLAGE DU PULSE
             if(pulse[0]!=0 && pulse[1] !=0){  
                
                // 2) CHERCHER LE PIC DANS CE PULSE
            
        	        //2.1)TROUVER LE POINT MAX LOCAL - justification de max = position central entre debut et fin de pulse fournie dans le rapport    
        	        // 3) SAUVEGARDER POINT MAX
                    position[nb_battements] = (pulse[1]-pulse[0])/2; // 2.1 et 3 fait en un
                    
                    // 4) REFAIRE POUR LE PROCHAIN PULSE
                    nb_battements++;
                    
                    pulse[0] = 0;
                    pulse[1] = 0;
            }
            
        }
        
        //5) CALCUL DE BPM
        
        BPM = 60*250/(position[1]-position[0]);
        
        if(nb_battements<2){ // retourner une valeur non-valide pour indiquer une erreur dans le calcul de BPM
            return 0;
        }
        
        return (uint8_t) BPM; // on retourne le bpm
}

float calculSPO2(uint16_t index){
    
        uint8_t nb_battements = 0;
        uint16_t position[2];
        float ratio = 0.0;

        
        //for(int i = index - BLOCK_SIZE; i<index; i++){
        for(int i =0; i<index; i++){
                if((i)){
                    
                    nb_battements++;
                    position[nb_battements]=i;
                    if(nb_battements > 1){
                        
                        ratio = (dataSpo2[RED][AC][i]*dataSpo2[IR][DC][i])/ (dataSpo2[RED][DC][i]*dataSpo2[IR][AC][i]);
                        
                        pourcentageSpO2 = -50*(ratio*ratio) + 5*ratio + 117;
                        
                        
                    }
                
                }
                
        
        }
        return  pourcentageSpO2; // on retourne le sp02

}

void filtrage(uint16_t index){
        
    
        //RED
        FiltreLowPass(&dataSpo2[RED][RAW][index],&dataSpo2[RED][DC][index]);
        FiltreHighPass(&dataSpo2[RED][DC][index],&dataSpo2[RED][AC][index]);

        /*
        //IR
        FiltreLowPass(&dataSpo2[IR][RAW][index],&dataSpo2[IR][DC][index]);
        FiltreHighPass(&dataSpo2[IR][RAW][index],&dataSpo2[IR][AC][index]);*/
        
}

void TraitementSignal( void*arg){ // cette tache a moins de priorité que la tache d'ecriture pour que l'index soit toujours en retard par rapport a l'ecriture.

    (void)arg;
    uint16_t indexLecture = 0;
    
    for(;;)
    {
      
       
        //a chaque seconde (donc a chaque 50 nouvelles donnees)
        if(((indexLecture+1)%BLOCK_SIZE)==0){
            
            //calculer BPM + SpO2
            filtrage(indexLecture);
            printf("FILTRAGE DONE \r\n");
            
            //BPM = calculBPM(indexLecture);
            //printf("bpm DONE \r\n");
            //printf("BPM : %d" , BPM);
            
            
            // pourcentageSpO2 = calculSPO2(indexLecture);
            //printf("SPO2 DONE \r\n");
            //printf("pourcentageSPO2 : %lu" , (long unsigned) pourcentageSpO2);
            
            
            printf("END if\r\n");
          
        }
        // printf("after the if\r\n");
        
        indexLecture++;
        if(indexLecture == TEST_LENGTH_SAMPLES){
            indexLecture = 0;
            printf("BEGIN DATA if\r\n");
            for(int i = 0; i<TEST_LENGTH_SAMPLES;i++){
                printf("%f,",dataSpo2[RED][AC][i]);
            }
            while(true);
        }
        
        
       vTaskDelay(pdMS_TO_TICKS(1));  
}

}

/* [] END OF FILE */
