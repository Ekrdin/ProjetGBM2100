/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "TraitementdeSignal.h"

 bool BuffRdy = true;

uint32_t blockSize=BLOCK_SIZE;
uint32_t numBlocks=TEST_LENGTH_SAMPLES/BLOCK_SIZE;
// Low pass pour avoir le DC
void FiltreLowPass(float* buffer ,float* filteredSignal) {
    
    //uint32_t compteur;
    arm_fir_instance_f32 S;
    arm_fir_init_f32(&S,NUM_TAPS,(float32_t *) &firCoeffs32_LowPass[0],&firStateF32[0],blockSize);
    arm_fir_f32(&S,buffer,filteredSignal,blockSize);
    
    //CECI EST UTILISE POUR FILTRER L'ENSEMBLE DES ENCHANTILLONS
   /* for (uint32_t compteur=0; compteur< numBlocks; compteur++){
        arm_fir_f32(&S,buffer + (compteur*blockSize),filteredSignal+ (compteur*blockSize),blockSize);
       
        
    }*/
}
    
// high pass pour avoir le AC
void FiltreHighPass(float* buffer ,float* filteredSignal) {
    
    //uint32_t compteur;
    arm_fir_instance_f32 S;
    arm_fir_init_f32(&S,NUM_TAPS,(float32_t *) & firCoeffs32_HighPass[0],&firStateF32[0],blockSize);
    arm_fir_f32(&S,buffer,filteredSignal,blockSize);
    
    //CECI EST UTILISE POUR FILTRER L'ENSEMBLE DES ENCHANTILLONS
    /*for (uint32_t compteur=0; compteur< numBlocks; compteur++){
        arm_fir_f32(&S,buffer + (compteur*blockSize),filteredSignal+ (compteur*blockSize),blockSize);
    }*/
    
}

void trouverZero(int* ZeroI, int* ZeroF, int* nZero){
    
    for ( int i= 0; i < BUFFER_LENGTH-1; i++){
        
    if ( dataSpo2[RED][AC][i] <0 && dataSpo2[RED][AC][i+1] > 0){
        
        (*nZero)++;
        // printf("1 \r\n");
            if((*nZero) == 1){
                //printf("2 \r\n");
                *ZeroI = i;
            }
            if( (*nZero) > 1){
                //printf("3 \r\n");
                *ZeroF = i;
            }
        }
    }
}

 uint8_t calculBPM(void){
    
    int ZeroIni = 0,
        ZeroFin = 0,
        nbrZero = 0;
    
        trouverZero(&ZeroIni,&ZeroFin,&nbrZero);
        
   // printf("%d \r\n", nbrZero);
   // printf("%d \r\n", ZeroFin);
    //printf("%d \r\n", ZeroIni);

         BPM = round (60*(nbrZero-1)*FREQUENCE_ECH/(ZeroFin-ZeroIni));
       return BPM;
}

float calculSPO2(void){
    
       double ratio = 0.0;
        float32_t MaxRedAC=0.0,
                  MinRedAC=0.0,
                  MaxIrAC=0.0,
                  MinIrAC=0.0,
                  moyenneRedDC,
                  moyenneIrDC;
    
        uint32_t indexMaxRedAC=0,
                 indexMaxIrAC=0,
                 indexMinRedAC=0,
                 indexMinIrAC=0,
                 RedAC,
                 IrAC,
                 MoyenneRedAC,
                 MoyenneIrAc;
                
    
    arm_max_f32(dataSpo2[RED][AC],BUFFER_LENGTH,&MaxRedAC,&indexMaxRedAC);
    arm_max_f32(dataSpo2[IR][AC],BUFFER_LENGTH,&MaxIrAC,&indexMaxIrAC);
    arm_min_f32(dataSpo2[RED][AC],BUFFER_LENGTH,&MinRedAC,&indexMinRedAC);
    arm_min_f32(dataSpo2[IR][AC],BUFFER_LENGTH,&MaxRedAC,&indexMinIrAC);
    
    
    RedAC = MaxRedAC - MinRedAC;
    IrAC = MaxIrAC - MinIrAC;
    
     arm_mean_f32(dataSpo2[RED][DC],BUFFER_LENGTH,&moyenneRedDC);
     arm_mean_f32(dataSpo2[IR][DC],BUFFER_LENGTH,&moyenneIrDC);
    
 ratio = (RedAC/moyenneRedDC)/(IrAC/moyenneIrDC); 
                        
 pourcentageSpO2 = -50*(ratio*ratio) + 5*ratio + 117;
               
        
        return  pourcentageSpO2; // on retourne le sp02

}

void filtrage(uint16_t index){
        
    
        //RED
        FiltreLowPass(&dataSpo2[RED][RAW][index],&dataSpo2[RED][DC][index]);
        //FiltreHighPass(&dataSpo2[RED][DC][index],&dataSpo2[RED][AC][index]);
        
        //IR
        FiltreLowPass(&dataSpo2[IR][RAW][index],&dataSpo2[IR][DC][index]);
        //FiltreHighPass(&dataSpo2[IR][DC][index],&dataSpo2[IR][AC][index]);
         for ( int i = 0; i < BUFFER_LENGTH; i++){ 
                
                dataSpo2[RED][AC][i]= dataSpo2[RED][DC][i] ;
                dataSpo2[IR][AC][i] = dataSpo2[IR][DC][i] ;
            }
        
}

void TraitementSignal( void*arg){ // cette tache a moins de priorité que la tache d'ecriture pour que l'index soit toujours en retard par rapport a l'ecriture.

    (void)arg;
    uint16_t indexLecture = 0;
     float32_t moyenneRED,
            moyenneIR;
  
    for(;;)
    {
      
        
        //a chaque 10 seconde (donc a chaque 50 nouvelles donnees)
        if(((indexLecture)%(BUFFER_LENGTH))==0 && indexLecture < BUFFER_LENGTH )
        {
               //printf("test1");
            
                //calculer BPM + SpO2
            
                filtrage(indexLecture);

            arm_mean_f32(dataSpo2[RED][AC],BUFFER_LENGTH,&moyenneRED);
            arm_mean_f32(dataSpo2[IR][AC],BUFFER_LENGTH,&moyenneIR);

            for ( int i = 0; i < BUFFER_LENGTH; i++){ 
                
                dataSpo2[RED][AC][i] -= moyenneRED;
                dataSpo2[IR][AC][i] -=  moyenneIR;
            }

            BPM = calculBPM();
                        
            printf("BPM : %d \r\n" , BPM);
            
            pourcentageSpO2 = calculSPO2();
                
            printf("pourcentageSPO2 : %lu" , (long unsigned) pourcentageSpO2);

          
            }
            // printf("after the if\r\n");
        
            indexLecture++;
            if(indexLecture == BUFFER_LENGTH){
                //indexLecture = 0;
                printf("BEGIN DATA if\r\n");
            
                for(int i = 0; i<BUFFER_LENGTH;i++){
                    //printf("%1.1f,",dataSpo2[RED][AC][i]);
                    
                }
            }
        
            bool BuffRdy = false; 
        vTaskDelay(pdMS_TO_TICKS(1));
       
        }
    
}

/* [] END OF FILE */
