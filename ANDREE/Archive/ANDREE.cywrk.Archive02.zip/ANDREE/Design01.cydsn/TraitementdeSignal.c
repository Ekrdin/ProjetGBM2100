/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "TraitementdeSignal.h"

 bool entree = true;

uint32_t blockSize=BLOCK_SIZE;
uint32_t numBlocks=TEST_LENGTH_SAMPLES/BLOCK_SIZE;

// Low pass pour avoir le DC
void FiltreLowPass(float* buffer ,float* filteredSignal) {
    
    //uint32_t compteur;
    arm_fir_instance_f32 S;
    arm_fir_init_f32(&S,NUM_TAPS,(float32_t *) &firCoeffs32_LowPass[0],&firStateF32[0],blockSize);
    arm_fir_f32(&S,buffer,filteredSignal,blockSize);
    
}
    
// high pass pour avoir le AC
void FiltreHighPass(float* buffer ,float* filteredSignal) {
    
    //uint32_t compteur;
    arm_fir_instance_f32 S;
    arm_fir_init_f32(&S,NUM_TAPS,(float32_t *) & firCoeffs32_HighPass[0],&firStateF32[0],blockSize);
    arm_fir_f32(&S,buffer,filteredSignal,blockSize);

}

void trouverZero(int* ZeroI, int* ZeroF, int* nZero){
    
    for ( int i= 0; i < BUFFER_LENGTH-1; i++){
        
    if ( dataSpo2[RED][AC][i] <0 && dataSpo2[RED][AC][i+1] > 0){
        
        (*nZero)++;
       
            if((*nZero) == 1){
               
                *ZeroI = i;
            }
            if( (*nZero) > 1){
                
                *ZeroF = i;
            }
        }
    }
}

 uint8_t calculBPM(void){
    
    int ZeroIni = 0,
        ZeroFin = 0,
        nbrZero = 0;
    
        trouverZero(&ZeroIni,&ZeroFin,&nbrZero);
        
         BPM = round (60*(nbrZero-1)*FREQUENCE_ECH/(ZeroFin-ZeroIni));
       return BPM;
}

float calculSPO2(void){
    
       double ratio = 0,
              RedAC=0,
              IrAC=0;
        float32_t MaxRedAC=0.0,
                  MinRedAC=0.0,
                  MaxIrAC=0.0,
                  MinIrAC=0.0,
                  moyenneRedDC=0.0,
                  moyenneIrDC=0.0;
    
        uint32_t indexMaxRedAC=0,
                 indexMaxIrAC=0,
                 indexMinRedAC=0,
                 indexMinIrAC=0;
                  

    arm_max_f32(dataSpo2[RED][AC],BUFFER_LENGTH,&MaxRedAC,&indexMaxRedAC);
    arm_max_f32(dataSpo2[IR][AC],BUFFER_LENGTH,&MaxIrAC,&indexMaxIrAC);
    arm_min_f32(dataSpo2[RED][AC],BUFFER_LENGTH,&MinRedAC,&indexMinRedAC);
    arm_min_f32(dataSpo2[IR][AC],BUFFER_LENGTH,&MinIrAC,&indexMinIrAC);
    
    
    RedAC = MaxRedAC - MinRedAC;
    IrAC = MaxIrAC - MinIrAC;
    
     arm_mean_f32(dataSpo2[RED][DC],BUFFER_LENGTH,&moyenneRedDC);
     arm_mean_f32(dataSpo2[IR][DC],BUFFER_LENGTH,&moyenneIrDC);
    
 ratio = (RedAC/moyenneRedDC)/(IrAC/moyenneIrDC); 
                        
 pourcentageSpO2 = round(-45.060*(ratio*ratio) +30.354*ratio + 110);
               
        
        return  pourcentageSpO2; // on retourne le sp02

}

void filtrage(uint16_t index){
        
    
        //RED
        FiltreLowPass(&dataSpo2[RED][RAW][index],&dataSpo2[RED][DC][index]);
        FiltreHighPass(&dataSpo2[RED][DC][index],&dataSpo2[RED][AC][index]);
        
        //IR
        FiltreLowPass(&dataSpo2[IR][RAW][index],&dataSpo2[IR][DC][index]);
        FiltreHighPass(&dataSpo2[IR][DC][index],&dataSpo2[IR][AC][index]);

}

void TraitementSignal( void*arg){ // cette tache a moins de priorité que la tache d'ecriture pour que l'index soit toujours en retard par rapport a l'ecriture.

    (void)arg;
    uint16_t indexLecture = 0;
     float32_t moyenneRED,
            moyenneIR;
  
    for(;;)
    {
      
        
        //a chaque 5 seconde (donc a chaque 1000 nouvelles donnees)
        if(((indexLecture)%(BUFFER_LENGTH))==0 && indexLecture < BUFFER_LENGTH && entree == true )
        {
              
                //Filtrage
            
                filtrage(indexLecture);

                //Centrer en 0
                arm_mean_f32(dataSpo2[RED][AC],BUFFER_LENGTH,&moyenneRED);
                arm_mean_f32(dataSpo2[IR][AC],BUFFER_LENGTH,&moyenneIR);

                for ( int i = 0; i < BUFFER_LENGTH; i++){ 
                
                dataSpo2[RED][AC][i] -= moyenneRED;
                dataSpo2[IR][AC][i] -=  moyenneIR;
                }
            
            //calculer BPM
            
            BPM = calculBPM();         
            
            //calculer  SpO2
            pourcentageSpO2 = calculSPO2();

          
        }
        
            indexLecture++;
            if(indexLecture == BUFFER_LENGTH){
                indexLecture = 0;  
             entree = false; 

            }
        
            
        vTaskDelay(pdMS_TO_TICKS(1));
       
    }
    
}

/* [] END OF FILE */
